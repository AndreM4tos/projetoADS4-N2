package br.senac.go.resources;

import br.senac.go.domain.Loja;
import br.senac.go.generics.GenericOperationsResource;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@RestController
@RequestMapping(path="/loja")
@Api(value="Operações para manipulação dos dados de loja",tags = "loja")
public class LojaResource implements GenericOperationsResource<Loja, Integer> {
    /**
     * Quando a pessoa for mandar um post, a aplicação
     * recebe uma entidade(E) e retorna a entidade (e) com o campo
     * id preenchido
     *
     * @param entity
     * @return
     */
    private static final Logger LOGGER = Logger.getLogger(Loja.class.getName());
    @Override
    @PostMapping(consumes = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
            produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
    @ApiOperation(value = "${resource.loja-post}", notes="Criar dado Loja." )
    @ApiResponses(value={
            @ApiResponse(code = 200, message = "Requisição feita com sucesso.", response = Loja.class),
            @ApiResponse(code = 201, message = "Registro criado com sucesso.", response = Loja.class),
            @ApiResponse(code = 204, message = "O servidor processou a solicitação com sucesso e não está retornando nenhum conteúdo.", response = Loja.class),
            @ApiResponse(code = 301, message = "Redirecionamento permanente.", response = Loja.class),
            @ApiResponse(code = 401, message = "Não autorizado.", response = Loja.class),
            @ApiResponse(code = 404, message = "Registro não encontrado.", response = Loja.class),
            @ApiResponse(code = 500, message = "Erro na requisão, verifique configurações do servidor.", response = Loja.class)
    })
    public Loja post(@RequestBody @Validated Loja entity) {
        LOGGER.log(Level.INFO, String.format("Exemplo do POST: %s", entity));

        return entity;
    }

    /**
     * Retorna uma lista de entidades
     *
     * @return
     */
    @Override
    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE,
            MediaType.APPLICATION_XML_VALUE})
    public List<Loja> get() {
        LOGGER.log(Level.INFO,
                String.format("Exemplo do GET:"));
        return null;
    }

    /**
     * Atualiza TODO o registro
     *
     * @param entity
     * @param id
     */
    @Override
    @PutMapping(value = "/{id}",consumes = {MediaType.APPLICATION_JSON_VALUE})
    public void put(@RequestBody @Validated Loja entity, @PathVariable ("id") Integer id) {
        LOGGER.log(Level.INFO,
                String.format("Exemplo do PUT: %s | %d", entity, id));
    }

    /**
     * Atualiza parcialmente um registro
     *
     * @param entity
     * @param id
     */
    @Override
    @PatchMapping(value ="/id",consumes = {MediaType.APPLICATION_JSON_VALUE})
    public void patch(@RequestBody @Validated Loja entity, @PathVariable("id") Integer id) {
        LOGGER.log(Level.INFO,
                String.format("Exemplo do PATCH: %s | %d", entity, id));
    }

    /**
     * Deleta um registro no banco;
     *
     * @param //entity
     */
    @Override
    @DeleteMapping(consumes = {MediaType.APPLICATION_JSON_VALUE})
    public void delete(@RequestBody Loja entity) {
        LOGGER.log(Level.INFO,
                String.format("Exemplo do DELETE: %s", entity));
    }

    /**
     * Deleta um registro no banco pelo identificador
     *
     * @param //id
     */
    @Override
    @DeleteMapping(value = "/{id}")
    public void deleteById(@PathVariable ("id") Integer id) {
        LOGGER.log(Level.INFO,
                String.format("Exemplo do DELETE by Id: %d", id));
    }

}
