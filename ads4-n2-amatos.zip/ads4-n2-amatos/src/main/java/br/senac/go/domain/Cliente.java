package br.senac.go.domain;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Entity
@Table(name = "cliente")
public class Cliente extends BaseModel {

    @Column(length = 50, nullable = false)
    private String nome;
    private String enderco;

    private LocalDateTime dataInicio;
    private LocalDateTime dataFim;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Carrinho> carrinhos;

}
