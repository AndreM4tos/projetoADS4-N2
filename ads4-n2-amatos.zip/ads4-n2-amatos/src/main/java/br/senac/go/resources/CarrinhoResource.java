package br.senac.go.resources;

import br.senac.go.domain.Carrinho;
import br.senac.go.domain.Produto;
import br.senac.go.generics.GenericOperationsResource;

import java.util.List;

public class CarrinhoResource implements GenericOperationsResource<Carrinho, Integer> {

    @Override
    public Carrinho post(Carrinho entity) {
        return null;
    }


    @Override
    public List<Carrinho> get() {
        return null;
    }


    @Override
    public void put(Carrinho entity, Integer id) {

    }


    @Override
    public void patch(Carrinho entity, Integer id) {

    }


    @Override
    public void delete(Carrinho entity) {

    }


    @Override
    public void deleteById(Integer id) {

    }
}
