package br.senac.go.domain;

import br.senac.go.domain.BaseModel;
import lombok.Data;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

@Data
@Entity
@Table(name = "loja")
public class Loja extends BaseModel {
    private String loja;
    private String enderco;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Cliente> clientes;

   }