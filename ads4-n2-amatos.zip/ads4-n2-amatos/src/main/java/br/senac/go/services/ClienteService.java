package br.senac.go.services;

import br.senac.go.domain.Cliente;
import br.senac.go.generics.IService;
import br.senac.go.repositories.ClienteRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Slf4j
public class ClienteService implements IService<Cliente, Integer> {

    /**
     * @Autowired fazer a injeção de dependênciada classe
     */
    @Autowired
    private ClienteRepository clienteRepository;

    @Override
    @Transactional
    public Cliente create(Cliente entity) {

        log.info("Método ClienteService.create invocado");
        log.debug("Valores informados ClienteService.create {}", entity);

        return this.clienteRepository.save(entity);
    }

    @Override
    public Cliente readById(Integer id) throws Exception {
        log.info("Método ClienteService.readById invocado");
        log.debug("Valores informados ClienteService.readById {}", id);

        Cliente cliente = this.clienteRepository
                .findById(id)
                .orElseThrow(() -> new Exception("Registro não encontrado."));

        log.debug("Valores recuperados em ClienteService.readById são {}", cliente);
        return cliente;
    }

    @Override
    public Cliente read(Cliente entity) throws Exception {

        log.info("Método ClienteService.read invocado");
        log.debug("Valores informados ClienteService.read {}", entity);

        Example<Cliente> clienteAprocurar = Example.of(entity);
        Cliente cliente = this.clienteRepository
                .findOne(clienteAprocurar)
                .orElseThrow(() -> new Exception("Registro não encontrado."));

        log.debug("Valores recuperados em ClienteService.read são {}", cliente);

        return cliente;
    }

    @Override
    @Transactional
    public Cliente updatePatch(Cliente entity, Integer id) throws Exception {
        log.info("Método ClienteService.updatePatch invocado");
        log.debug("Valores informados ClienteService.updatePatch {} {}", entity, id);


        /**
         *  Exemplo 3, para evitar a situação do exemplo 2, precisamos seguir os seguintes passos:
         *  1. Fazer uma pesquisa para verificar se o ID existe
         *  2. Se existir, fazer a atualização.
         */

       boolean registroEncontrado = this.clienteRepository.findById(id).isPresent();
       Cliente clienteAtualizada;

       if(registroEncontrado) {
           entity.setId(id);
           clienteAtualizada = this.clienteRepository.save(entity);
       }
       else {
           log.error("Error: ClienteService.updatePatch ao atualizar registro: {} {}",
                   entity, id);
           throw new Exception("Erro ao atualizar regitro");
       }


        log.debug("Valores atualizados em ClienteService.updatePatch são {}", clienteAtualizada);

        return clienteAtualizada;
    }

    @Override
    @Transactional
    public Cliente updatePut(Cliente entity, Integer id) {
        log.info("Método ClienteService.updatePatch invocado");
        log.debug("Valores informados PessoaService.updatePatch {} {}", entity, id);

        log.debug("Valores recuperados em PessoaService.read são {}", entity);

        return null;
    }

    @Override
    @Transactional
    public Cliente deleteById(Integer id) {
        return null;
    }

    @Override
    @Transactional
    public Cliente delete(Cliente entity) {
        return null;
    }
}
