package br.senac.go.domain;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
@Table(name = "carrinho")
public class Carrinho extends BaseModel {
    private String carrinho;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Produto> produtos;
   }