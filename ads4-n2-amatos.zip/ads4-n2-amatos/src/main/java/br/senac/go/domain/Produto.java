package br.senac.go.domain;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Entity
@Table(name = "produto")
public class Produto extends BaseModel {

    private String produto;
    private Float preco;
    private LocalDateTime dataInicio;
    private LocalDateTime dataFim;

}
