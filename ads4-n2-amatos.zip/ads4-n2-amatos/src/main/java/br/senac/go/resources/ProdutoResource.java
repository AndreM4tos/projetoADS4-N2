package br.senac.go.resources;

import br.senac.go.domain.Produto;
import br.senac.go.generics.GenericOperationsResource;

import java.util.List;

public class ProdutoResource implements GenericOperationsResource<Produto, Integer> {

    @Override
    public Produto post(Produto entity) {
        return null;
    }


    @Override
    public List<Produto> get() {
        return null;
    }


    @Override
    public void put(Produto entity, Integer id) {

    }


    @Override
    public void patch(Produto entity, Integer id) {

    }


    @Override
    public void delete(Produto entity) {

    }


    @Override
    public void deleteById(Integer id) {

    }
}
